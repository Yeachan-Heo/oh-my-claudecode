# Migration Guide

This guide covers all migration paths for oh-my-claudecode. Find your current version below.

---

## Table of Contents

- [Unreleased: Host Load Gate Threshold Values](#unreleased-host-load-gate-threshold-values)
- [Unreleased: Rule Glob Brace Alternation](#unreleased-rule-glob-brace-alternation)
- [Unreleased: Glossary File Rename (CONTEXT.md → GLOSSARY.md)](#unreleased-glossary-file-rename-contextmd--glossarymd)
- [Unreleased: Shipyard Tracker Artifacts and Audit Contract v2](#unreleased-shipyard-tracker-artifacts-and-audit-contract-v2)
- [Unreleased: SSRF Guard for IPv6 Literals](#unreleased-ssrf-guard-for-ipv6-literals)
- [Unreleased: Team Instance Ownership](#unreleased-team-instance-ownership)
- [Unreleased: Cancellation Scope](#unreleased-cancellation-scope)
- [v4.x → v5.0: Workflow Retirement](#v4x--v50-workflow-retirement)
- [Unreleased: Team MCP Runtime Deprecation (CLI-Only)](#unreleased-team-mcp-runtime-deprecation-cli-only)
- [Unreleased: Native Team Worktree Mode (Opt-In)](#unreleased-native-team-worktree-mode-opt-in)
- [Unreleased: Git-less State Root Recovery](#unreleased-git-less-state-root-recovery)
- [v3.5.3 → v3.5.5: Test Fixes & Cleanup](#v353--v355-test-fixes--cleanup)
- [v3.5.2 → v3.5.3: Skill Consolidation](#v352--v353-skill-consolidation)
- [v2.x → v3.0: Package Rename & Auto-Activation](#v2x--v30-package-rename--auto-activation)
- [v3.0 → v3.1: Notepad Wisdom & Enhanced Features](#v30--v31-notepad-wisdom--enhanced-features)
- [v3.x → v4.0: Major Architecture Overhaul](#v3x--v40-major-architecture-overhaul)

---

## Unreleased: Host Load Gate Threshold Values

Negative values for `OMC_HOST_LOAD_THRESHOLD`, `OMC_FREE_MEMORY_THRESHOLD`, and
`OMC_MAX_SIBLING_SESSIONS` now fall back to their documented defaults instead of
disabling individual checks. Existing environment configurations that use `-1`
can therefore re-enable a check after upgrading.

### Migration

- Remove a negative threshold variable to use its default value.
- Set `OMC_HOST_LOAD_GATE_DISABLED=1` to disable the entire host load gate.
- To disable an individual check from code, pass a negative value through a
  `HostLoadGateConfig` override; negative environment values no longer disable
  individual checks.

## Unreleased: Rule Glob Brace Alternation

Rule frontmatter `globs` and Claude Code `paths` now treat unescaped `{a,b}`
as alternation. Existing patterns that used comma-bearing braces to match a
literal path must escape both braces and keep the pattern as one array item:

```yaml
globs:
  - 'fixtures/\{a,b\}.json'
```

Use a quoted inline or block array item as shown; an unquoted comma-separated
scalar still treats commas outside brace groups as pattern separators.

## Unreleased: Glossary File Rename (CONTEXT.md → GLOSSARY.md)

The shipyard glossary surface is now `GLOSSARY.md` at the repository root. It holds the yard's terms and the `documentLanguage` frontmatter tag.

### What changes for existing yards

- **Only `CONTEXT.md` exists:** the yard keeps working. The audit accepts `CONTEXT.md` as the glossary, and the skills read it until it is migrated. The next full `/oh-my-claudecode:drydock` run (not `--check`) renames it to `GLOSSARY.md` with its content and frontmatter unchanged, and rewrites `CONTEXT.md` references in `CLAUDE.md` (for example `Glossary: CONTEXT.md`) to `GLOSSARY.md`. Commit the result.
- **Both files exist:** `node scripts/shipyard-audit.mjs` reports a high-confidence `shipyard.glossary.duplicate-authority` finding and exits 1, so Launch stays blocked. Drydock does not merge the files for you. Move any terms that exist only in `CONTEXT.md` into `GLOSSARY.md`, delete `CONTEXT.md`, replace remaining `CONTEXT.md` references in `CLAUDE.md` with `GLOSSARY.md`, then commit.
- **Fresh yards:** no action. Drydock creates `GLOSSARY.md`.

A `CONTEXT.md` counts as a legacy glossary only when its frontmatter has a `documentLanguage` key, or its first visible non-blank line (after the frontmatter, ignoring a BOM and HTML comments) is a drydock glossary seed heading (`# Glossary`, `# 术语表`, `# 詞彙表`) for yards laid before the language tag existed. Any other `CONTEXT.md` (for example an agent-context file) is ignored by the audit and never renamed.

## Unreleased: Shipyard Tracker Artifacts and Audit Contract v2

New navigator maps and Launch specs/tickets are tracker-only. For an existing `.omc/wayfinder/<slug>/map.md`, use ask-navigator's one-time migration: create the tracker map issue and child issues, carry over decisions, frontier, dependencies, and mission brief, then verify the import before treating the tracker as canonical. Keep local files unchanged until that verification is complete; do not create new local maps.

Launch recovery uses the parent spec issue, its native child issues, and the latest handoff comment on the parent. Put settled decisions in their child issues and progress pointers, open questions, next watch, and warning lines in a tracker comment. Do not create local spec, ticket, or handoff files.

### Audit contract v2

The `node scripts/shipyard-audit.mjs` JSON report now includes `contractVersion: 2`. This version retires the `shipyard.surface.missing.*` finding family: absence of an optional surface means it is not adopted, not that the yard is incomplete. Consumers that keyed on those IDs must stop treating absent optional paths as findings. The required base faces are handled separately by `shipyard.yard.unlaid`: `CLAUDE.md` and `GLOSSARY.md` must exist, or a recognizable legacy glossary `CONTEXT.md` may stand in until a full drydock run migrates it. Integrity checks still run on adopted surfaces.

## Unreleased: SSRF Guard for IPv6 Literals

OMC's URL guard now rejects literal IPv6 unique-local (`FC00::/7`), link-local
(`FE80::/10`), unspecified (`::`), and multicast (`FF00::/8`) addresses. This
affects `GITEA_URL` when OMC uses its direct REST fallback. A blocked Gitea URL
disables that fallback. This change does not alter HUD usage routing for an
IPv6-literal `ANTHROPIC_BASE_URL`: provider selection checks the supported DNS
hostnames, and other endpoints follow the existing Anthropic OAuth usage path.
The guard does not override Claude Code's own model requests.

### Migration

- For self-hosted Gitea on a unique-local address, configure the `tea` CLI for
  that host; OMC can continue to use the CLI path, while its direct REST fallback
  intentionally fails closed for blocked literals. If you rely on the REST
  fallback, expose Gitea through a trusted routable endpoint outside the blocked
  ranges.
- There is no SSRF-guard opt-out. Do not use a hostname that resolves to the same
  private address as a workaround; DNS resolution and redirect validation are
  separate protections not provided by this guard.

---

## Unreleased: Team Instance Ownership

Team startup reserves an immutable instance ID before creating tasks or workers.
An existing reservation or team state is not overwritten by another start using
the same name. CLI/MCP jobs retain their original instance ID: cleanup of an old
job cannot adopt a newer team's configuration.

Native CLI jobs no longer start through the legacy v1 opt-out path. Unset
`OMC_RUNTIME_V2=0`, `false`, `no`, or `off` before starting a job; disabling v2 is
rejected before native startup effects rather than selecting weaker cleanup.

Cleanup now requires matching instance and worker-launch evidence. A missing or
corrupt receipt is not permission to kill a pane or remove state, even with
`--force`. Older jobs and teams without this evidence are preserved rather than
automatically upgraded or forcibly deleted. Complete their shutdown using the
owning runtime before upgrading; do not fabricate IDs or discard receipts to
bypass a blocked cleanup.

This also applies to API `cleanup` and `orphan-cleanup`: neither is a raw state
deletion escape hatch. The unsafe low-level `teamCleanup` deletion API is removed.
SessionEnd cleanup checks the ending Claude session's ownership via config
`leader_session_id` (not the tmux target projected into `leader.session_id`)
and passes the captured instance ID; stale team-name hints cannot authorize
cleanup of another session's team.

Provider execution and pane liveness are observed separately. An exited provider
can be recovered even when its pane shell remains, but recovery does not treat
that observation as proof that all descendant processes have terminated.

Tmux ownership additionally binds the socket, server PID, and precise process
creation time captured at startup. Reused session names or pane IDs after a
server restart cannot replace that evidence. Missing historical server identity
does not authorize adoption, input, or destruction. Confirmed death of the
original server proves only that its panes are gone, not provider cleanup.
Strict server identity requires the native addon on macOS or boot-bound process
evidence on Linux; unavailable precision preserves resources without a coarse
process-listing fallback.
Native Windows/MSYS tmux control has no verified process-identity mapping and
therefore cannot authorize these effects. Running Node inside WSL uses the Linux
identity path.

The legacy mutation exports `watchdogCliWorkers`, `spawnWorkerForTask`,
`killWorkerPane`, `assignTask`, and `killWorkerPanes` have been removed. Use the instance-bound v2
startup, dispatch, recovery, scaling, and shutdown APIs instead. The former
`done.json` watchdog, five automatic pane-death retries, lowest-index scheduling,
and watchdog timer `stop()` contract are retired, not recreated inside v2.

Final state removal retains instance-bound cleanup records outside the disposable
team directory. After a partial removal failure, retry cleanup for the original
job. Do not manually delete these records, including completed receipts: they
prevent reuse of a retired instance identity. Detached state is removed by the
validated cleanup protocol.

Pending recovery reservations, intents, and owner requests also retain the
original instance ID. Records without that evidence are not automatically
adopted, and retrying an old request cannot attach it to a same-named replacement.

`state_clear(mode="team", ...)` clears orchestration/session state, not native
team runtime directories or name-only native mission records. Shut down native
teams through `omc team shutdown` or the original job's cleanup API first.
Session ownership alone does not prove ownership of a same-name runtime instance.

## Unreleased: Cancellation Scope

`/oh-my-claudecode:cancel --force` now targets only the current session; it no longer
means clearing every session. It skips graceful waits, not state locks or ownership checks.
If the current session cannot be identified, cancellation fails closed.

Use `--all` explicitly for all-session cancellation. It follows normal cancellation
within each session; use `--force --all` when forced cancellation across sessions is intended.
Update prompts or automation that previously used `--force` for a workspace-wide reset.
The deprecated `cancel-ralph` alias follows the same contract.

## Unreleased: Git-less State Root Recovery

### TL;DR

Sessions launched outside a Git repository no longer create a separate `.omc/`
directory for every cwd. OMC uses one canonical `~/.omc/` root, or
`$OMC_STATE_DIR/non-git` when centralized state is configured. Protected
locations and descendants of system temp/OS roots are never used as roots.

### Migration and compatibility

- Existing non-git `.omc/` roots remain untouched and are not adopted implicitly.
  Use `state_migrate_non_git` with the owning `session_id` to copy matching JSON
  records into the canonical root without overwriting or deleting sources.
- Existing state under protected locations is never moved or deleted
  automatically, and cannot be used as a migration source.
- `OMC_STATE_DIR` remains the explicit centralized option. In git-less sessions
  it uses one fixed `non-git` child rather than hashing each cwd.
- `workingDirectory` on state tools is honored within the validated context;
  foreign repositories and failed Git probes are rejected visibly.
- Session-scoped state remains owned by its `session_id`. No time-based cleanup
  or cancellation was added.

---

## v4.x → v5.0: Workflow Retirement

### TL;DR

17 workflow names were **removed outright**, not kept as aliases. The public
surface is now four canonical workflows — `plan` → `execute` → `review` →
`verify` — plus a small set of independent workflows and utilities.

If you use `/ultrawork`, `/ultraqa`, `/ccg`, `/sciomc`, `/deep-dive`,
`/omc-teams`, `/setup`, `/mcp-setup`, `/learner`, or `/writer-memory`, those
names no longer resolve. Use the replacement in the table below.

### Removed skills and commands

| Removed                | Replacement                              | Notes                                                        |
| ---------------------- | ---------------------------------------- | ------------------------------------------------------------ |
| `ultrawork`            | `/oh-my-claudecode:execute` or `/team`   | Use `/team` when you want coordinated parallel workers        |
| `ultrapilot`           | `/oh-my-claudecode:team`                 | Declared-only; never shipped as a skill file                  |
| `swarm`                | `/oh-my-claudecode:team`                 | Declared-only                                                 |
| `pipeline`             | `/oh-my-claudecode:execute`              | Declared-only                                                 |
| `ultraqa`              | `/oh-my-claudecode:verify`               |                                                               |
| `merge-readiness`      | `/oh-my-claudecode:review`               | MCP tools and runtime are removed; review stays advisory; release hard checks are unchanged |
| `deep-dive`            | `/oh-my-claudecode:research`             |                                                               |
| `sciomc`               | `/oh-my-claudecode:research`             |                                                               |
| `ccg`                  | `/oh-my-claudecode:ask` + `/team`        | Run `/ask codex` and `/ask antigravity`, then synthesize      |
| `omc-teams`            | `/oh-my-claudecode:team` or `omc team`   |                                                               |
| `setup`                | `/oh-my-claudecode:omc-setup`            |                                                               |
| `mcp-setup`            | Claude Code native MCP configuration     | Use `claude mcp add <name> ...` or the path selected by `CLAUDE_MCP_CONFIG_PATH`. |
| `omc-reference`        | `/oh-my-claudecode:wiki`                 | Model-routing reference moved into the wiki skill             |
| `learner`              | `/oh-my-claudecode:remember`             |                                                               |
| `writer-memory`        | `/oh-my-claudecode:remember`             |                                                               |
| `local-build-reminder` | —                                        | Removed; docs and CI cover the rebuild signal                 |
| `understanding-gate`   | `/oh-my-claudecode:review`               | Frontmatter alias of the removed merge-readiness              |

Command files removed alongside their skills: `ccg.md`, `deep-dive.md`,
`learner.md`, `mcp-setup.md`, `omc-teams.md`, `sciomc.md`, `writer-memory.md`.

### What is kept

These were **not** retired, despite routing into the canonical workflows:

- **Canonical Tier-0**: `plan`, `execute`, `review`, `verify`
- **Independent Tier-0 planning**: `deep-interview`, `ralplan`
- **Directly invocable workflows**: `autopilot`, `autoresearch`, `ultragoal`, `ralph`
- **Internal lanes**: `team`, `research`
- **Surviving aliases**: `psm` → `project-session-manager`, `release` → maintainer-only `omc release`

### Newly available to everyone

`verify`, `remember`, and `debug` were previously gated behind an internal
entitlement (`USER_TYPE=ant`). They now install for all users — `verify`
completes the canonical chain and `remember` is the target for the retired
`learner`/`writer-memory`.

### Installed names

Two skills install under an `omc-` prefix because their names collide with
Claude Code native commands:

| Skill    | Installed as |
| -------- | ------------ |
| `plan`   | `omc-plan`   |
| `review` | `omc-review` |

### Migration Steps

1. Update any scripts, docs, or prompts that invoke a removed name.
2. Run `omc setup` (or `/oh-my-claudecode:omc-setup`). The installer prunes the
   retired skill directories automatically — no manual cleanup needed.
3. If you pinned a removed skill in `.claude/settings.json` or a project
   `CLAUDE.md`, replace it using the table above.

### Why these were removed rather than aliased

The alias retirement policy normally requires ≥2 minor releases, ≥90 days, and
≥95% canonical usage before a name can be removed. A major version is the
sanctioned place for breaking removals, so 5.0.0 applies a major-boundary
carve-out (`isMajorBoundaryRemoval`). The carve-out does **not** waive the
critical-integrations check — an alias with a known critical consumer still
blocks.

---

## Unreleased: Team MCP Runtime Deprecation (CLI-Only)

### TL;DR

`omc_run_team_start/status/wait/cleanup` are now hard-deprecated at runtime. Calls return:

```json
{
  "code": "deprecated_cli_only",
  "message": "Legacy team MCP runtime tools are deprecated. Use the omc team CLI instead."
}
```

Use CLI commands instead:

- `omc team [N:agent-type] "<task>"`
- `omc team status <team-name>`
- `omc team shutdown <team-name> [--force]`
- `omc team api <operation> --input '<json>' --json`

### `omc ask` env alias sunset (Phase-1 compatibility)

`OMC_ASK_*` is now canonical for advisor execution. Phase-1 accepts `OMX_ASK_ADVISOR_SCRIPT` and `OMX_ASK_ORIGINAL_TASK` with deprecation warnings. Planned hard sunset for alias removal: **2026-06-30**.

### How to Migrate

1. Replace MCP runtime tool calls with CLI equivalents.
2. Update skills/prompts from `/omc-teams ...` to `omc team ...` syntax.
3. Legacy Team MCP runtime is now opt-in only (not enabled by default). If you enable it manually, treat responses as deprecation-only compatibility output.

### Example mapping

```bash
# Old (deprecated runtime path)
mcp__team__omc_run_team_start(...)
mcp__team__omc_run_team_status({ job_id: ... })
mcp__team__omc_run_team_wait({ job_id: ... })
mcp__team__omc_run_team_cleanup({ job_id: ... })

# New (CLI-first)
omc team 2:codex "review auth flow"
omc team status review-auth-flow
omc team shutdown review-auth-flow --force
omc team api list-tasks --input '{"team_name":"review-auth-flow"}' --json
```

---

## Unreleased: Native Team Worktree Mode (Opt-In)

### TL;DR

`omc team` runtime-v2 is gaining an opt-in worker worktree mode. Worktree-backed workers run from dedicated git worktrees while task lifecycle, mailbox, status, and manifest files stay under the leader workspace's team-specific coordination root (`<repo>/.omc/state/team/<team-name>`).

### Contract

- Worktree paths use `<repo>/.omc/team/<team-name>/worktrees/<worker-name>`.
- `OMC_TEAM_STATE_ROOT` points workers back to `<repo>/.omc/state/team/<team-name>`.
- Status/config/manifest/identity surfaces should expose `workspace_mode`, `worktree_mode`, `team_state_root`, and worker worktree metadata.
- Dirty worker worktrees are preserved and reported; they are not force-cleaned by shutdown/cleanup.

See [Native Team Worktree Mode](TEAM-WORKTREE-MODE.md) for the full rollout contract and verification checklist.

## v3.5.3 → v3.5.5: Test Fixes & Cleanup

### TL;DR

Maintenance release fixing test suite issues and continuing skill consolidation from v3.5.3.

### What Changed

**Test Fixes:**

- Delegation-enforcer tests marked as skipped (implementation pending)
- Analytics expectations corrected for agent attribution
- All remaining tests now pass cleanly

**Skill Consolidation:**

- Continued cleanup from v3.5.3
- Removed deprecated `cancel-*` skills (use `/cancel` instead)
- Final skill count: 37 core skills

### Migration Steps

1. **No breaking changes** - All functionality preserved
2. **Test suite** now runs cleanly with `npm run test:run`
3. **Deprecated skills** removed (already replaced in v3.5.3)

### For Developers

If you were depending on deprecated `cancel-*` skills, update to use the unified `/cancel` command which auto-detects the active mode.

---

## v3.5.2 → v3.5.3: Skill Consolidation

### TL;DR

8 deprecated skills have been removed. The unified `/cancel` and `/omc-setup` commands replace them.

### Removed Skills

The following skills have been **completely removed** in v3.5.3:

| Removed Skill        | Replacement                            |
| -------------------- | -------------------------------------- |
| `cancel-autopilot`   | `/oh-my-claudecode:cancel`             |
| `cancel-ralph`       | `/oh-my-claudecode:cancel`             |
| `cancel-ultrawork`   | `/oh-my-claudecode:cancel`             |
| `cancel-ultraqa`     | `/oh-my-claudecode:cancel`             |
| `omc-default`        | `/oh-my-claudecode:omc-setup --local`  |
| `omc-default-global` | `/oh-my-claudecode:omc-setup --global` |
| `planner`            | `/oh-my-claudecode:plan`               |

### What Changed

**Before v3.5.3:**

```bash
/oh-my-claudecode:cancel-ralph      # Cancel ralph specifically
/oh-my-claudecode:omc-default       # Configure local project
/oh-my-claudecode:planner "task"    # Start planning
```

**After v3.5.3:**

```bash
/oh-my-claudecode:cancel            # Auto-detects and cancels any active mode
/oh-my-claudecode:omc-setup --local # Configure local project
/oh-my-claudecode:plan "task"       # Start planning (includes interview mode)
```

### New Features

**New skill: `/learn-about-omc`**

- Analyzes your OMC usage patterns
- Provides personalized recommendations
- Identifies underutilized features

**Plan skill now supports consensus mode:**

```bash
/oh-my-claudecode:plan --consensus "task"  # Iterative planning with Critic review
/oh-my-claudecode:ralplan "task"           # Alias for plan --consensus
```

### Migration Steps

1. **No action required** - The unified `/cancel` command already worked in v3.5
2. **Update any scripts** that reference removed commands
3. **Re-run `/omc-setup`** if you want to update your CLAUDE.md configuration

### Skill Count

- v3.5: 42 skills
- v3.5.3: 37 skills (8 removed, 3 added)

---

## v2.x → v3.0: Package Rename & Auto-Activation

### TL;DR

Your old commands still work! But now you don't need them.

**Before 3.0:** Explicitly invoke 25+ commands like `/oh-my-claudecode:ralph "task"`, `/oh-my-claudecode:ultrawork "task"`

**After 3.0:** Just work naturally - Claude auto-activates the right behaviors. One-time setup: just say "setup omc"

### Project Rebrand

The project was rebranded to better reflect its purpose and improve discoverability.

- **Project/brand name**: `oh-my-claudecode` (GitHub repo, plugin name, commands)
- **npm package name**: `oh-my-claude-sisyphus` (unchanged)

> **Why the difference?** The npm package name `oh-my-claude-sisyphus` was kept for backward compatibility with existing installations. The project, GitHub repository, plugin, and all commands use `oh-my-claudecode`.

#### NPM Install Command (unchanged)

```bash
npm i -g oh-my-claude-sisyphus@latest
```

### What Changed

#### Before (2.x): Explicit Commands

You had to remember and explicitly invoke specific commands for each mode:

```bash
# 2.x workflow: Multiple commands, lots to remember
/oh-my-claudecode:ralph "implement user authentication"       # Persistence mode
/oh-my-claudecode:ultrawork "refactor the API layer"          # Maximum parallelism
/oh-my-claudecode:planner "plan the new dashboard"            # Planning interview
/oh-my-claudecode:deepsearch "find database schema files"     # Deep search
/oh-my-claudecode:git-master "commit these changes"           # Git expertise
/oh-my-claudecode:deepinit ./src                              # Index codebase
/oh-my-claudecode:analyze "why is this test failing?"         # Deep analysis
```

#### After (3.0): Auto-Activation + Keywords

Work naturally. Claude detects intent and activates behaviors automatically:

```bash
# 3.0 workflow: Just talk naturally OR use optional keywords
"don't stop until user auth is done"                # Auto-activates ralph-loop
"fast: refactor the entire API layer"               # Auto-activates ultrawork
"plan: design the new dashboard"                    # Auto-activates planning
"ralph ulw: migrate the database"                   # Combined: persistence + parallelism
"find all database schema files"                    # Auto-activates search mode
"commit these changes properly"                     # Auto-activates git expertise
```

### Agent Naming Standard

Agent naming is now strictly descriptive and role-based (for example: `architect`, `planner`, `analyst`, `critic`, `document-specialist`, `designer`, `writer`, `vision`, `executor`).

Use canonical role names across prompts, commands, docs, and scripts. Avoid introducing alternate myth-style or legacy aliases in new content.

### Directory and Environment Migration

No directory rename is required for the current OMC state paths. Keep existing `.omc/` project state and `~/.omc/` global state directories in place.

Only update genuinely legacy or custom paths that predate the OMC layout:

| Area | Old | New |
| ---- | --- | --- |
| Config file | `~/.claude/omc/mnemosyne.json` | `~/.claude/omc/learner.json` |

Environment variables that already use the `OMC_` prefix do not need renaming. Continue using the existing documented variables such as `OMC_LSP_TOOLS`, `OMC_PARALLEL_EXECUTION`, and `OMC_DEBUG`.

### Command Mapping

All 2.x commands continue to work. Here's what changed:

| 2.x Command                            | 3.0 Equivalent                                     | Works?                 |
| -------------------------------------- | -------------------------------------------------- | ---------------------- |
| `/oh-my-claudecode:ralph "task"`       | Say "don't stop until done" OR use `ralph` keyword | ✅ YES (both ways)     |
| `/oh-my-claudecode:ultrawork "task"`   | Say "fast" or "parallel" OR use `ulw` keyword      | ✅ YES (both ways)     |
| `/oh-my-claudecode:ultrawork-ralph`    | Say "ralph ulw:" prefix                            | ✅ YES (keyword combo) |
| `/oh-my-claudecode:planner "task"`     | Say "plan this" OR use `plan` keyword              | ✅ YES (both ways)     |
| `/oh-my-claudecode:plan "description"` | Start planning naturally                           | ✅ YES                 |
| `/oh-my-claudecode:review [path]`      | Invoke normally                                    | ✅ YES (unchanged)     |
| `/oh-my-claudecode:deepsearch "query"` | Say "find" or "search"                             | ✅ YES (auto-detect)   |
| `/oh-my-claudecode:analyze "target"`   | Say "analyze" — routes to debugger/architect agent | ✅ YES (keyword route) |
| `/oh-my-claudecode:deepinit [path]`    | Invoke normally                                    | ✅ YES (unchanged)     |
| `/oh-my-claudecode:git-master`         | Say "git", "commit", "atomic commit"               | ✅ YES (auto-detect)   |
| `/oh-my-claudecode:frontend-ui-ux`     | Say "UI", "styling", "component", "design"         | ✅ YES (auto-detect)   |
| `/oh-my-claudecode:note "content"`     | Say "remember this" or "save this"                 | ✅ YES (auto-detect)   |
| `/oh-my-claudecode:cancel-ralph`       | Say "stop", "cancel", or "abort"                   | ✅ YES (auto-detect)   |
| `/oh-my-claudecode:omc-doctor`         | Invoke normally                                    | ✅ YES (unchanged)     |
| All other commands                     | Work exactly as before                             | ✅ YES                 |

### Magic Keywords

Include these anywhere in your message to explicitly activate behaviors. Use keywords when you want explicit control (optional):

| Keyword             | Effect                                   | Example                           |
| ------------------- | ---------------------------------------- | --------------------------------- |
| `ralph`             | Persistence mode - won't stop until done | "ralph: refactor the auth system" |
| `ralplan`           | Iterative planning with consensus        | "ralplan: add OAuth support"      |
| `ulw` / `ultrawork` | Maximum parallel execution               | "ulw: fix all type errors"        |
| `plan`              | Planning interview                       | "plan: new API design"            |

**ralph includes ultrawork:**

```
ralph: migrate the entire database
    ↓
Persistence (won't stop) + Ultrawork (maximum parallelism) built-in
```

**No keywords?** Claude still auto-detects:

```
"don't stop until this works"      # Triggers ralph
"fast, I'm in a hurry"             # Triggers ultrawork
"help me design the dashboard"     # Triggers planning
```

### Natural Cancellation

Say any of these to stop:

- "stop"
- "cancel"
- "abort"
- "nevermind"
- "enough"
- "halt"

Claude intelligently determines what to stop:

```
If in ralph-loop     → Exit persistence loop
If in ultrawork      → Return to normal mode
If in planning       → End planning interview
If multiple active   → Stop the most recent
```

No more `/oh-my-claudecode:cancel-ralph` - just say "cancel"!

### Migration Steps

Follow these steps to migrate your existing setup:

#### 1. Uninstall Old Package (if installed via npm)

```bash
npm uninstall -g oh-my-claude-sisyphus
```

#### 2. Install via Plugin System

```bash
# In Claude Code:
/plugin marketplace add https://github.com/Yeachan-Heo/oh-my-claudecode
/plugin install oh-my-claudecode
```

> **Note**: npm/bun global installs no longer provide the in-session plugin surface by themselves. Use the plugin system for slash commands, hooks, and skills; use the published npm package `oh-my-claude-sisyphus` when you need the terminal `omc` CLI.

#### 3. Preserve Existing OMC Directories

Do not rename current OMC directories. Existing project state in `.omc/` and global state in `~/.omc/` are already on the current paths.

#### 4. Update Legacy Config Names

If you still have the pre-3.0 learner config filename, rename only that file:

```bash
mv ~/.claude/omc/mnemosyne.json ~/.claude/omc/learner.json
```

#### 5. Review Scripts and Configurations

Search your local scripts and docs for stale references to removed commands or the old config filename. Keep the npm package name as `oh-my-claude-sisyphus` for npm/bun installs; do not rewrite it to the project/plugin brand name.

#### 6. Run One-Time Setup

In Claude Code, just say "setup omc", "omc setup", or any natural language equivalent.

This:

- Downloads latest CLAUDE.md
- Configures 32 agents
- Enables auto-behavior detection
- Activates continuation enforcement
- Sets up skill composition

### Verification

After migration, verify your setup:

1. **Check CLI installation, if you use the npm CLI surface**:

   ```bash
   npm list -g oh-my-claude-sisyphus
   ```

2. **Verify directories exist**:

   ```bash
   ls -la .omc/  # In project directory
   ls -la ~/.omc/  # Global directory
   ```

3. **Test a simple command**:
   Run `/oh-my-claudecode:omc-help` in Claude Code to ensure the plugin is loaded correctly.

### New Features in 3.0

#### 1. Zero-Learning-Curve Operation

**No commands to memorize.** Work naturally:

```
Before: "OK, I need to use /oh-my-claudecode:ultrawork for speed..."
After:  "I'm in a hurry, go fast!"
        ↓
        Claude: "I'm activating ultrawork mode..."
```

#### 2. Delegate Always (Automatic)

Complex work auto-routes to specialist agents:

```
Your request              Claude's action
────────────────────     ────────────────────
"Refactor the database"   → Delegates to architect
"Fix the UI colors"       → Delegates to designer
"Document this API"       → Delegates to writer
"Search for all errors"   → Delegates to explore
"Debug this crash"        → Delegates to architect
```

You don't ask for delegation - it happens automatically.

#### 3. Learned Skills (`/oh-my-claudecode:skillify`)

Extract reusable insights from problem-solving. `/oh-my-claudecode:learner` remains as a deprecated compatibility alias:

```bash
# After solving a tricky bug:
"Extract this as a skill"
    ↓
Claude learns the pattern and stores it
    ↓
Next time keywords match → Solution auto-injects
```

Storage:

- **Project-level**: `.omc/skills/` (intended to be committed with the repo; uncommitted worktree-local skills disappear when that worktree is removed)
- **User-level**: `~/.claude/skills/omc-learned/` (portable)

#### 4. HUD Statusline (Real-Time Orchestration)

See what Claude is doing in the status bar:

```
[OMC] ralph:3/10 | US-002 | ultrawork skill:planner | ctx:67% | agents:2 | todos:2/5
```

Run `/oh-my-claudecode:hud setup` to install. Presets: minimal, focused, full.

#### 5. Three-Tier Memory System

Critical knowledge survives context compaction:

```
<remember priority>API client at src/api/client.ts</remember>
    ↓
Permanently loaded on session start
    ↓
Never lost through compaction
```

Or use `/oh-my-claudecode:note` to save discoveries manually:

```bash
/oh-my-claudecode:note Project uses PostgreSQL with Prisma ORM
```

#### 6. Structured Task Tracking (PRD Support)

**Ralph Loop now uses Product Requirements Documents:**

```bash
/oh-my-claudecode:ralph-init "implement OAuth with multiple providers"
    ↓
Auto-creates PRD with user stories
    ↓
Each story: description + acceptance criteria + pass/fail
    ↓
Ralph loops until ALL stories pass
```

#### 7. Intelligent Continuation

**Tasks complete before Claude stops:**

```
You: "Implement user dashboard"
    ↓
Claude: "I'm activating ralph-loop to ensure completion"
    ↓
Creates todo list, works through each item
    ↓
Only stops when EVERYTHING is verified complete
```

### Backward Compatibility Note

**Note**: v3.0 does not maintain backward compatibility with v2.x naming. You must complete the migration steps above for the new version to work correctly.

---

## v3.0 → v3.1: Notepad Wisdom & Enhanced Features

### Overview

Version 3.1 is a minor release adding powerful new features while maintaining full backward compatibility with v3.0.

### What's New

#### 1. Notepad Wisdom System

Plan-scoped wisdom capture for learnings, decisions, issues, and problems.

**Location:** `.omc/notepads/{plan-name}/`

| File           | Purpose                            |
| -------------- | ---------------------------------- |
| `learnings.md` | Technical discoveries and patterns |
| `decisions.md` | Architectural and design decisions |
| `issues.md`    | Known issues and workarounds       |
| `problems.md`  | Blockers and challenges            |

**API:**

- `initPlanNotepad()` - Initialize notepad for a plan
- `addLearning()` - Record technical discoveries
- `addDecision()` - Record architectural choices
- `addIssue()` - Record known issues
- `addProblem()` - Record blockers
- `getWisdomSummary()` - Get summary of all wisdom
- `readPlanWisdom()` - Read full wisdom for context

#### 2. Delegation Categories

Semantic task categorization that auto-maps to model tier, temperature, and thinking budget.

| Category             | Tier   | Temperature | Thinking | Use For                                         |
| -------------------- | ------ | ----------- | -------- | ----------------------------------------------- |
| `visual-engineering` | HIGH   | 0.7         | high     | UI/UX, frontend, design systems                 |
| `ultrabrain`         | HIGH   | 0.3         | max      | Complex reasoning, architecture, deep debugging |
| `artistry`           | MEDIUM | 0.9         | medium   | Creative solutions, brainstorming               |
| `quick`              | LOW    | 0.1         | low      | Simple lookups, basic operations                |
| `writing`            | MEDIUM | 0.5         | medium   | Documentation, technical writing                |

**Auto-detection:** Categories detect from prompt keywords automatically.

#### 3. Directory Diagnostics Tool

Project-level type checking via `lsp_diagnostics_directory` tool.

**Strategies:**

- `auto` (default) - Auto-selects best strategy, prefers tsc when tsconfig.json exists
- `tsc` - Fast, uses TypeScript compiler
- `lsp` - Fallback, iterates files via Language Server

**Usage:** Check entire project for errors before commits or after refactoring.

#### 4. Session Resume

Background agents can be resumed with full context via `resume-session` tool.

### Migration Steps

Version 3.1 is a drop-in upgrade. No migration required!

```bash
npm update -g oh-my-claude-sisyphus
```

All existing configurations, plans, and workflows continue working unchanged.

### New Tools Available

Once upgraded, agents automatically gain access to:

- Notepad wisdom APIs (read/write wisdom during execution)
- Delegation categories (automatic categorization)
- Directory diagnostics (project-level type checking)
- Session resume (recover background agent state)

---

## v3.3.x → v3.4.0: Parallel Execution & Advanced Workflows

### Overview

Version 3.4.0 introduces powerful parallel execution modes and advanced workflow orchestration while maintaining full backward compatibility with v3.3.x.

### What's New

#### 1. Pipeline: Sequential Agent Chaining

Chain agents with data passing between stages:

```bash
/oh-my-claudecode:pipeline explore:haiku -> architect:opus -> executor:sonnet
```

**Built-in Presets:**

- `review` - explore → architect → critic → executor
- `implement` - planner → executor → tdd-guide
- `debug` - explore → architect → debugger
- `research` - parallel(document-specialist, explore) → architect → writer
- `refactor` - explore → architect → executor (with model="opus") → qa-tester
- `security` - explore → security-reviewer → executor

#### 4. Unified Cancel Command

Smart cancellation that auto-detects active mode:

```bash
/oh-my-claudecode:cancel
# Or just say: "stop", "cancel", "abort"
```

**Auto-detects and cancels:** autopilot, ralph, ultrawork, pipeline (ultraqa is retired; stale pre-5.0.0 `ultraqa-state.json` is still cleared)

**Deprecation Notice:**
Individual cancel commands are deprecated but still work:

- `/oh-my-claudecode:cancel-ralph` (deprecated)
- `/oh-my-claudecode:cancel-ultraqa` (deprecated)
- `/oh-my-claudecode:cancel-ultrawork` (deprecated)
- `/oh-my-claudecode:cancel-autopilot` (deprecated)

Use `/oh-my-claudecode:cancel` instead.

#### 6. Explore-High Agent

Opus-powered architectural search for complex codebase exploration:

```typescript
Task(
  (subagent_type = "oh-my-claudecode:explore"),
  (model = "opus"),
  (prompt = "Find all authentication-related code patterns..."),
);
```

**Best for:** Architectural analysis, cross-cutting concerns, complex refactoring planning

#### 7. State Management Standardization

State files now use standardized paths:

**Standard paths:**

- Local: `.omc/state/{name}.json`
- Global: `~/.omc/state/{name}.json`

Legacy locations are auto-migrated on read.

#### 8. Keyword Conflict Resolution

When multiple execution mode keywords are present:

**Conflict Resolution Priority:**
| Priority | Condition | Result |
|----------|-----------|--------|
| 1 (highest) | Single explicit keyword | That mode wins |
| 2 | Generic "fast"/"parallel" only | Read from config (`defaultExecutionMode`) |
| 3 (lowest) | No config file | Default to `ultrawork` |

**Explicit mode keywords:** `ulw`, `ultrawork`
**Generic keywords:** `fast`, `parallel`

Users set their default mode preference via `/oh-my-claudecode:omc-setup`.

### Migration Steps

Version 3.4.0 is a drop-in upgrade. No migration required!

```bash
npm update -g oh-my-claude-sisyphus
```

All existing configurations, plans, and workflows continue working unchanged.

### New Configuration Options

#### Default Execution Mode

Set your preferred execution mode in `~/.claude/.omc-config.json`:

```json
{
  "defaultExecutionMode": "ultrawork"
}
```

When you use generic keywords like "fast" or "parallel" without explicit mode keywords, this setting determines which mode activates.

### Breaking Changes

None. All v3.3.x features and commands continue to work in v3.4.0.

### New Tools Available

Once upgraded, you automatically gain access to:

- Ultrapilot (parallel autopilot)
- Swarm coordination
- Pipeline workflows
- Unified cancel command
- Explore-high agent

### Best Practices for v3.4.0

#### When to Use Each Mode

| Scenario                | Recommended Mode | Why                                            |
| ----------------------- | ---------------- | ---------------------------------------------- |
| Multi-component systems | `team N:executor` | Parallel workers handle independent components |
| Many small fixes        | `team N:executor` | Atomic task claiming prevents duplicate work   |
| Sequential dependencies | `pipeline`        | Data passes between stages                     |
| Single complex task     | `autopilot`      | Full autonomous execution                      |
| Must complete           | `ralph`          | Persistence guarantee                          |

#### Keyword Usage

**Explicit mode control (v3.4.0):**

```bash
"ulw: fix all errors"           # ultrawork (explicit)
"fast: implement feature"       # reads defaultExecutionMode config
```

**Natural language (still works):**

```bash
"don't stop until done"         # ralph
"parallel execution"            # reads defaultExecutionMode
"build me a todo app"           # autopilot
```

### Verification

After upgrading, verify new features:

1. **Check CLI installation, if you use the npm CLI surface**:

   ```bash
   npm list -g oh-my-claude-sisyphus
   ```

2. **Test unified cancel**:

   ```bash
   /oh-my-claudecode:cancel
   ```

3. **Check state directory**:
   ```bash
   ls -la .omc/state/
   ```

---

## v3.x → v4.0: Major Architecture Overhaul

### Overview

Version 4.0 is a complete architectural redesign focusing on scalability, maintainability, and developer experience.

### What's Coming

⚠️ **This section is under active development as v4.0 is being built.**

#### Planned Changes

1. **Modular Architecture**
   - Plugin system for extensibility
   - Core/extension separation
   - Better dependency management

2. **Enhanced Agent System**
   - Improved agent lifecycle management
   - Better error recovery
   - Performance optimizations

3. **Improved Configuration**
   - Unified config schema
   - Better validation
   - Migration tooling

4. **Breaking Changes**
   - TBD based on development progress
   - Full migration guide will be provided

### Migration Path (Coming Soon)

Detailed migration instructions will be provided when v4.0 reaches release candidate status.

Expected timeline: Q1 2026

### Stay Updated

- Watch the [GitHub repository](https://github.com/Yeachan-Heo/oh-my-claudecode) for announcements
- Check [CHANGELOG.md](../CHANGELOG.md) for detailed release notes
- Join discussions in GitHub Issues

---

## Common Scenarios Across Versions

### Scenario 1: Quick Implementation Task

**2.x Workflow:**

```
/oh-my-claudecode:ultrawork "implement the todo list feature"
```

**3.0+ Workflow:**

```
"implement the todo list feature quickly"
    ↓
Claude: "I'm activating ultrawork for maximum parallelism"
```

**Result:** Same outcome, more natural interaction.

### Scenario 2: Complex Debugging

**2.x Workflow:**

```
/oh-my-claudecode:ralph "debug the memory leak"
```

**3.0+ Workflow:**

```
"there's a memory leak in the worker process - don't stop until we fix it"
    ↓
Claude: "I'm activating ralph-loop to ensure completion"
```

**Result:** Ralph-loop with more context from your natural language.

### Scenario 3: Strategic Planning

**2.x Workflow:**

```
/oh-my-claudecode:planner "design the new authentication system"
```

**3.0+ Workflow:**

```
"plan the new authentication system"
    ↓
Claude: "I'm starting a planning session"
    ↓
Interview begins automatically
```

**Result:** Planning interview triggered by natural language.

### Scenario 4: Stopping Work

**2.x Workflow:**

```
/oh-my-claudecode:cancel-ralph
```

**3.0+ Workflow:**

```
"stop"
```

**Result:** Claude intelligently cancels the active operation.

---

## Configuration Options

### Project-Scoped Configuration (Recommended)

Apply oh-my-claudecode to current project only:

```
/oh-my-claudecode:omc-default
```

Creates: `./.claude/CLAUDE.md`

### Global Configuration

Apply to all Claude Code sessions:

```
/oh-my-claudecode:omc-default-global
```

Creates: `~/.claude/CLAUDE.md`

**Precedence:** Project config overrides global if both exist.

---

## FAQ

**Q: Do I have to use keywords?**
A: No. Keywords are optional shortcuts. Claude auto-detects intent without them.

**Q: Will my old commands break?**
A: No. All commands continue to work across minor versions (3.0 → 3.1). Major version changes (3.x → 4.0) will provide migration paths.

**Q: What if I like explicit commands?**
A: Keep using them! `/oh-my-claudecode:ralph`, `/oh-my-claudecode:ultrawork`, and `/oh-my-claudecode:plan` work. Note: `/oh-my-claudecode:planner` now redirects to `/oh-my-claudecode:plan`.

**Q: How do I know what Claude is doing?**
A: Claude announces major behaviors: "I'm activating ralph-loop..." or set up `/oh-my-claudecode:hud` for real-time status.

**Q: Where's the full command list?**
A: See [README.md](../README.md) for full command reference. All commands still work.

**Q: What's the difference between keywords and natural language?**
A: Keywords are explicit shortcuts. Natural language triggers auto-detection. Both work.

---

## Need Help?

- **Diagnose issues**: Run `/oh-my-claudecode:omc-doctor`
- **See all commands**: Run `/oh-my-claudecode:omc-help`
- **View real-time status**: Run `/oh-my-claudecode:hud setup`
- **Review detailed changelog**: See [CHANGELOG.md](../CHANGELOG.md)
- **Report bugs**: [GitHub Issues](https://github.com/Yeachan-Heo/oh-my-claudecode/issues)

---

## What's Next?

Now that you understand the migration:

1. **For immediate impact**: Start using keywords (`ralph`, `ulw`, `plan`) in your work
2. **For full power**: Read [docs/CLAUDE.md](CLAUDE.md) to understand orchestration
3. **For advanced usage**: Check [docs/ARCHITECTURE.md](ARCHITECTURE.md) for deep dives
4. **For team onboarding**: Share this guide with teammates

Welcome to oh-my-claudecode!
