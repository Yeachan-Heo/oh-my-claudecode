#!/usr/bin/env node
/* global process, console, fetch, AbortController, setTimeout, clearTimeout, Buffer */
/**
 * Jev script-side judgment channel (ADR 03671, ticket 15).
 *
 * Plain-Node hook scripts cannot import TypeScript. They consult the judgment
 * program through this one-shot child process: the caller writes one JSON
 * request to stdin and reads one JSON result from stdout.
 *
 * Request:  { point, state, questions, heuristic, permissionMode? }
 * Result:   { mode, answer, confidence, durationMs }
 *
 * mode mirrors the resolver's ResolveMode contract: off (config gates),
 * shadow (twin decides, comparison recorded), active (Jev decides), degraded
 * (a Jev call was attempted and failed - caller falls back to its twin).
 * The calling script computes its own heuristic twin; this child never sees
 * the twin's code. Request cap and circuit breaker are in-process resolver
 * runtime - meaningless for a one-shot child and intentionally omitted.
 * Degrade-never-block: any failure exits 0 with mode:"degraded" so a hook
 * process is never killed by a Jev outage.
 *
 * The env parse below mirrors src/hooks/jev/config.ts (same contract: keys,
 * defaults, all/point:active syntax). jev-eval.mjs sets the precedent for
 * deliberate mirrors; parity with the TS parse is locked by the test suite.
 */

import { lstatSync, readFileSync, rmdirSync, unlinkSync } from "node:fs";
import { appendFile, mkdir } from "node:fs/promises";
import { basename, dirname, join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { pathToFileURL } from "node:url";

import { resolveOmcStateRoot } from "./lib/state-root.mjs";

const DEFAULT_ENDPOINT = "https://api.typesafe.ai/v1/systemone";
const DEFAULT_TIMEOUT_MS = 2000;
const DEFAULT_EXCERPT_CHARS = 200;
const MAX_TIMER_DELAY_MS = 2_147_483_647;
const JEV_MODEL = "jev-latest";

function positiveInt(raw, fallback, max = Number.MAX_SAFE_INTEGER) {
  if (typeof raw !== "string" || !/^[1-9]\d*$/.test(raw)) return fallback;
  const parsed = Number(raw);
  return Number.isSafeInteger(parsed) && parsed <= max ? parsed : fallback;
}

/**
 * Resolve the script-side Jev timeout using the same strict contract for the
 * HTTP resolver and its synchronous active-mode parent process.
 */
export function resolveJevTimeoutMs(env = process.env, bufferMs = 0) {
  const timeoutMs = positiveInt(
    env.OMC_JEV_TIMEOUT_MS,
    DEFAULT_TIMEOUT_MS,
    MAX_TIMER_DELAY_MS,
  );
  const buffer =
    Number.isSafeInteger(bufferMs) && bufferMs > 0
      ? Math.min(bufferMs, MAX_TIMER_DELAY_MS)
      : 0;
  return Math.min(timeoutMs + buffer, MAX_TIMER_DELAY_MS);
}

/**
 * Mirror of serializeQuestions in src/hooks/jev/client.ts. `score` questions
 * are rejected with HTTP 422 unless their criteria are an ordered low-to-high
 * list; `choice`/`noul` take the named map unchanged (#4091).
 */
export function serializeQuestions(questions) {
  const out = {};
  for (const [name, question] of Object.entries(questions ?? {})) {
    out[name] =
      question?.type === "score" &&
      question.criteria &&
      !Array.isArray(question.criteria)
        ? { ...question, criteria: Object.values(question.criteria) }
        : question;
  }
  return out;
}

/**
 * Mirror of parseJevConfig + pointState in src/hooks/jev/config.ts. Returns
 * the tri-state decision the TS resolver makes for one point:
 * off | shadow | active.
 *
 * permissionMode is the hook input's permission_mode. In Claude Code plan
 * mode, OMC_JEV_PLAN_MODE=shadow runs opted-in points in shadow and
 * OMC_JEV_PLAN_MODE=off turns them off; any other value changes nothing.
 * Script channel only: the TS resolver receives no permission mode.
 */
export function parseJevEnv(point, env = process.env, permissionMode) {
  const raw = (env.OMC_JEV || "").trim();
  if (!env.TYPESAFE_API_KEY || raw === "off") return "off";
  let sawAll = false;
  let activateAll = false;
  let active = false;
  let listed = false;
  for (const entry of raw.split(",")) {
    const token = entry.trim();
    if (!token) continue;
    const colon = token.lastIndexOf(":");
    const name = colon === -1 ? token : token.slice(0, colon);
    const isActive = colon !== -1 && token.slice(colon + 1) === "active";
    if (name === "all") {
      sawAll = true;
      if (isActive) activateAll = true;
    } else if (name === point) {
      listed = true;
      if (isActive) active = true;
    }
  }
  if (!sawAll && !listed) return "off";
  if (permissionMode === "plan") {
    const planMode = (env.OMC_JEV_PLAN_MODE || "").trim();
    if (planMode === "shadow" || planMode === "off") return planMode;
  }
  if (activateAll || active) return "active";
  return "shadow";
}

/** Mirror of boundExcerpts in config.ts: recursively bound strings to max chars. */
export function boundExcerpts(value, max) {
  if (typeof value === "string")
    return value.length > max ? value.slice(0, max) : value;
  if (Array.isArray(value))
    return value.map((item) => boundExcerpts(item, max));
  if (value !== null && typeof value === "object") {
    const out = {};
    for (const [key, val] of Object.entries(value))
      out[key] = boundExcerpts(val, max);
    return out;
  }
  return value;
}

/** Mirror of validateJevResponse in client.ts. Throws on any invalid shape. */
export function validateJevResponse(body) {
  if (body === null || typeof body !== "object")
    throw new Error("invalid response: expected object");
  const answers = body.answers;
  if (
    answers === null ||
    typeof answers !== "object" ||
    Array.isArray(answers)
  ) {
    throw new Error("invalid response: missing answers object");
  }
  const entries = Object.entries(answers);
  if (entries.length === 0)
    throw new Error("invalid response: answers is empty");
  for (const [name, answer] of entries) {
    if (
      answer === null ||
      typeof answer !== "object" ||
      typeof answer.type !== "string"
    ) {
      throw new Error(
        'invalid response: answer "' + name + '" has no string type',
      );
    }
  }
  return body;
}

async function logDirFor(env) {
  if (env.OMC_JEV_LOG_DIR) return env.OMC_JEV_LOG_DIR;
  const omcRoot = await resolveOmcStateRoot(process.cwd());
  return join(omcRoot, "state", "jev");
}

/**
 * Mirror of the resolver's shadow-log entry (ShadowLogEntry): the jev-eval
 * tool compares lines regardless of which side wrote them.
 */
async function writeShadowLog(entry, logDir) {
  try {
    await mkdir(logDir, { recursive: true });
    await appendFile(
      join(logDir, "shadow.jsonl"),
      JSON.stringify(entry) + "\n",
      "utf8",
    );
  } catch {
    // Best-effort logging: a logging failure must never affect the judgment.
  }
}

/**
 * One judgment request: config gates, bounded fetch, validated response,
 * shadow-log line. Never throws - every failure degrades to mode:"degraded".
 * fetchFn is a test hook.
 */
export async function resolveRequest(
  request,
  env = process.env,
  fetchFn = fetch,
) {
  const startedAt = Date.now();
  const mode = parseJevEnv(request.point, env, request.permissionMode);
  if (mode === "off") {
    return { mode, answer: null, confidence: undefined, durationMs: 0 };
  }
  const bound = boundExcerpts(
    { state: request.state, questions: request.questions },
    positiveInt(env.OMC_JEV_EXCERPT_CHARS, DEFAULT_EXCERPT_CHARS),
  );
  const controller = new AbortController();
  let timer;
  const timeoutMs = resolveJevTimeoutMs(env);
  const timeoutPromise = new Promise((resolve, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new Error("jev request timed out after " + timeoutMs + "ms"));
    }, timeoutMs);
  });
  let jevAnswer = null;
  let confidence;
  let entryMode = mode;
  try {
    const response = await Promise.race([
      fetchFn(env.OMC_JEV_ENDPOINT || DEFAULT_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + env.TYPESAFE_API_KEY,
        },
        body: JSON.stringify({
          state: bound.state,
          questions: serializeQuestions(bound.questions),
          model: JEV_MODEL,
        }),
        signal: controller.signal,
      }),
      timeoutPromise,
    ]);
    if (!response.ok)
      throw new Error("jev request failed: HTTP " + response.status);
    const body = validateJevResponse(await response.json());
    jevAnswer = Object.values(body.answers)[0];
    confidence = jevAnswer.confidence;
  } catch (error) {
    entryMode = "degraded";
    console.error(
      "[jev] " +
        request.point +
        ": degraded - " +
        (error instanceof Error ? error.message : String(error)),
    );
  } finally {
    if (timer) clearTimeout(timer);
  }
  const durationMs = Date.now() - startedAt;
  await writeShadowLog(
    {
      ts: new Date().toISOString(),
      point: request.point,
      mode: entryMode,
      state: bound.state,
      heuristic: request.heuristic ?? null,
      jev: entryMode === "degraded" ? null : jevAnswer,
      confidence,
      durationMs,
    },
    await logDirFor(env),
  );
  return {
    mode: entryMode,
    answer: entryMode === "degraded" ? null : jevAnswer,
    confidence,
    durationMs,
  };
}

/** Read one JSON request from stdin, print one JSON result to stdout. */
export async function readStdinJson() {
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(chunk);
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

/**
 * Read one JSON request from a file and delete it. Used by fire-and-record
 * callers that exit immediately after spawning, where a stdin pipe would race
 * the parent's exit. The request carries raw tool input, so it must never be
 * passed on argv: /proc/<pid>/cmdline is world-readable.
 */
export function readRequestFile(path) {
  let raw;
  const dir = dirname(resolve(path));
  try {
    raw = readFileSync(path, "utf8");
  } finally {
    try {
      unlinkSync(path);
    } catch {
      // The request may already be gone or unavailable for cleanup.
    }

    try {
      const safeTmpDir = resolve(tmpdir());
      const dirBasename = basename(dir);
      const dirStats = lstatSync(dir);

      // Only remove an empty, owned Jev directory directly under os.tmpdir().
      if (
        dirname(dir) === safeTmpDir &&
        dirBasename.startsWith("omc-jev-") &&
        dirStats.isDirectory() &&
        (typeof process.getuid !== "function" ||
          dirStats.uid === process.getuid())
      ) {
        rmdirSync(dir);
      }
    } catch {
      // Best effort: temp dir cleanup is best-effort; never block on it.
    }
  }
  if (!raw) throw new Error("Failed to read request file");
  return JSON.parse(raw);
}

const isMain =
  Boolean(process.argv[1]) &&
  import.meta.url === pathToFileURL(process.argv[1]).href;
if (isMain) {
  try {
    const requestFileFlag = process.argv.indexOf("--request-file");
    const requestFile =
      requestFileFlag === -1 ? undefined : process.argv[requestFileFlag + 1];
    const request = requestFile
      ? readRequestFile(requestFile)
      : await readStdinJson();
    const result = await resolveRequest(request);
    console.log(JSON.stringify(result));
  } catch (error) {
    console.error(
      "[jev] " + (error instanceof Error ? error.message : String(error)),
    );
    console.log(
      JSON.stringify({
        mode: "degraded",
        answer: null,
        confidence: undefined,
        durationMs: 0,
      }),
    );
  }
}
